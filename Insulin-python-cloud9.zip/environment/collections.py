myFavouriteFruitDictionary = {
    "Elvis" : "pineaple",
    "Victor" : "banana",
    "Gerald" : "watermelon"
}
print(myFavouriteFruitDictionary["Elvis"])
print(myFavouriteFruitDictionary["Victor"])
print(myFavouriteFruitDictionary["Gerald"])


