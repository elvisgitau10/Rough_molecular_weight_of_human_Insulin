import re
lines = ORIGIN      
        1 malwmrllpl lallalwgpd paaafvnqhl cgshlvealy lvcgergffy tpktrreaed
       61 lqvgqvelgg gpgagslqpl alegslqkrg iveqcctsic slyqlenycn
//
re.sub(pattern = "[^\w\s]",
        repl = "",
        string = lines)
        

    
    