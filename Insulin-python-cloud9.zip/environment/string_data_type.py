name = input("what is your name? ")
color = input("What is your favourite color? ")
animal = input("what is your favourite animal? ")
print("{}, you like a {} {}!".format(name,color,animal))



